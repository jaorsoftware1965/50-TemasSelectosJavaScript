// -------------------------------------
// Listas Doblemente enlazadas
// -------------------------------------

// Graficamente una lista enlazada
// 
//   Cabeza
//     |
//     |
//   dato--> dato--> ..... dato--null
   
// Graficamente una lista doblemente enlazada
//      Cabeza                        Cola
//         |                           |
//         |                           |
//  null--dato--><--dato--> ..... <--dato--null

// 2 casos de insercion
// 1) cuando la lista doblemente enlazada esta vacia
//     Cabeza  Cola
//          |  |
//   null--dato01--null
// 

// 2) cuando la lista doblemente enlazada no esta vacia
//       Cabeza       Cola
//          |           |
//  null--dato02--><--dato01--null
// 

// Clase para el Nodo
class nodo 
{
    // Constructor recibe el dato del nodo
    constructor(dato) 
    {
        // Propiedad para el dato
        this.dato = dato
        
        // Propiedad para enlazar al siguiente nodo
        this.siguiente = null                

        // Propiedad para enlazar al nodo anterior
        this.anterior = null
    }
}

// Clase para la lista doblemente enlazada
class listaDoblementeEnlazada
{
    // Constructor
    constructor() 
    {
        // Propiedad Cabeza y Cola 
        this.cabeza = null
        this.cola   = null
        console.log ("Se ha creado la lista doblemente enlazada vacía ...")
    }

    // Insertar un elemento en la lista
    insertar(dato)
    {
        // Crea un nodo con el dato
        let nodoNuevo = new nodo(dato)
        
        // Verificamos si la cabeza es null
        if (this.cabeza==null)
        {
            // Lo asignamos a la cabeza y a la cola
            this.cabeza = nodoNuevo
            this.cola   = nodoNuevo

            // Mensaje
            console.log("Se ha insertado el elemento "+ dato +" en lista vacía")
        }
        else
        {
           // Apunta el nodo nuevo al que apunta cabeza
           nodoNuevo.siguiente = this.cabeza

           // EL Nodo al que apunta cabeza le indicamos su anterior apunte
           // al nuevo nodo
           this.cabeza.anterior = nodoNuevo

           // Apuntamos al Nuevo nodo
           this.cabeza = nodoNuevo

           // Mensaje
           console.log("Se ha insertado el elemento "+dato+" en cabeza")
        }
    }

    // listar los datos
    listar()
    {
        // Obtiene el apuntador a la cabeza
        let nodo = this.cabeza
        let cuenta = 0
        
        // Mensaje
        console.log("Lista de Elementos ...")

        // Ciclo mientras nodo no apunte a null
        while (nodo)
        {
            // Despliega el nodo
            console.log(nodo.dato)
            
            // Incrementa el contador
            cuenta++

            // Navega al siguiente nodo
            nodo = nodo.siguiente
        }
        console.log ("La lista contiene:"+cuenta+" elemento(s)")
    }

    // listar los datos en inverso
    listarInverso()
    {
        // Obtiene el apuntador a la cabeza
        let nodo = this.cola
        let cuenta = 0

        // Mensaje
        console.log("Lista de Elementos Inversa...")

        // Ciclo mientras nodo no apunte a null
        while (nodo)
        {
            // Despliega el nodo
            console.log(nodo.dato)
            
            // Incrementa el contador
            cuenta++

            // Navega al anterior nodo
            nodo = nodo.anterior
        }
        console.log ("La lista contiene:"+cuenta+" elemento(s)")
    }

    // Despliega el primer elemento
    getPrimero()
    {
        // Despliega
        if (this.cabeza!=null)
           console.log("Primero: "+this.cabeza.dato)
        else
           console.log("No hay elementos en la lista")
    }

    // Despliega el primer ultimo
    getUltimo()
    {
        // Despliega
        if (this.cola!=null)
            console.log("Ultimo: "+this.cola.dato)
        else
            console.log("No hay elementos en la lista")
    }

    // Limpiar la lista
    limpiar()
    {
        // Solamente coloca a null la cabeza
        this.cabeza = null
        this.cola = null
    }
}

// Crea la lista
listaNueva = new listaDoblementeEnlazada()

// Insertamos 3 elementos
listaNueva.insertar("Jhon")
listaNueva.insertar("James")
listaNueva.insertar("Paul")

// Listamos
listaNueva.listar()

// Listamos Inverso
listaNueva.listarInverso()

// Obtenemos el primero y el ultimo
listaNueva.getPrimero()
listaNueva.getUltimo()

// Limpiamos
listaNueva.limpiar()

// Listamos
listaNueva.listar()
