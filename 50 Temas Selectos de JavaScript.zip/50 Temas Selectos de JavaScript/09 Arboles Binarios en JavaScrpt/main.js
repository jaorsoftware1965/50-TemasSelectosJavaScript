// -------------------------------------
// Arboles Binarios BTree en JavaScript
// -------------------------------------

// Un Arbol Binario es un conjunto de nodos, los cuales contienen
// un dato, y un apuntador a un Nodo Hijo Izquierdo y un apuntador
// a un Nodo Hijo Derecho

// Al primer nodo del árbol se le conoce como raiz

// Graficamente un árbol binario
// Secuencia: 10, 12, 5, -9, 9, 34, 11

//                         Raiz
//                          |
//                          10  
//                 5                 12
//            -9       9         11      34

// Recorridos:
// inOrder;   primero Izq, Raiz y Der  --> -9,  5, 9
// preOrder;  primero Raiz, Izq y Der  -->  5, -9, 9
// postOrder; primero Izq, Der, y Raiz --> -9,  9, 5

// Clase Nodo
class nodo 
{
    // Constructor
    constructor (dato) 
    {
        // Propiedades
        this.dato  = dato
        this.hDer  = null
        this.hIzq  = null
    }
}
  
// La Clase Arbol
class arbolBinario
{        
    // Constructor
    constructor () 
    {
        this.raiz = null
    }
  
    // Verifica si está vacío
    estaVacio () 
    {
        // Retorna
        return this.raiz === null
    }
  
    // Insertar un elemento
    insertar (dato) 
    {
        // arbol no tiene elementos
        if (this.estaVacio()) 
        {
             // Asigna el nuevo nodo a la raiz
             this.raiz = new nodo(dato)
             return
        }
  
        // Variable auxiliar para navegar
        var aux = this.raiz
  
        // Mientras haya nodo que visita
        while (aux) 
        {
            // vamos hacia la izquierda
            if (dato <= aux.dato) 
            {
               // Verifica si hay a la izquierda
               if (aux.hIzq) 
               {
                  // Pasa a la izquierda
                  aux = aux.hIzq
               } 
               else 
               {
                   // Si no tiene izquierda ahí lo deposita
                   aux.hIzq = new nodo(dato)
                   return
               }
            } 
            else 
            { 
               // vamos hacia la derecha
               if (aux.hDer) 
               {
                  // Navega a la derecha                 
                  aux = aux.hDer
               } 
               else 
               {
                  // Lo coloca a la derecha
                  aux.hDer = new nodo(dato)
                  return
               }
            }
        }
    }
  
    // Insertar Recursivamente
    insertarRecursivamente(dato, xNodo = this.raiz) 
    {
       // Verifica que no exista nodo
       if (!xNodo) 
       {
          // Si no hay nodo, ahi lo inserta
          this.raiz = new nodo(dato)
          return
       }
   
       // Verifica si el dato a insertar es menor
       if (dato <= xNodo.dato) 
       {
          // Verifica si hay izquierdo 
          if (xNodo.hIzq) 
          {
             // Llama a la función 
             return this.insertarRecursivamente(dato, xNodo.hIzq)
          }          
          // Si no hay izquierdo lo inserta
          xNodo.hIzq = new nodo(dato)
          return
       } 
       else 
       { 
          // vamos hacia la derecha
          if (xNodo.hDer) 
          {
             // Recursividad hacia Derecha
             return this.insertarRecursivamente(dato, xNodo.hDer)
          }
          // Si no tiene lo coloca a la derecha
          xNodo.hDer = new nodo(dato)
          return
       }
    }
      
    // Desplegar inOrder; primero Izq, Raiz y Der
    inOrder (xNodo = this.raiz) 
    {
       // Verifica si no tiene nodo
       if (!xNodo) 
       {
          // Returna si no
          return
       }

       // Busca el Nodo Izquierdo
       this.inOrder(xNodo.hIzq)

       // Despliega el Nodo, raiz
       console.log(xNodo.dato)

       // Busca el Nodo Derecho
       this.inOrder(xNodo.hDer)
    }

    // Desplegar preOrder; primero la raíz, izq y der
    preOrder (xNodo = this.raiz) 
    {
       // Verifica el Nodo
       if (!xNodo) 
       {
         return
       }
       // Despliega primero la raiz
       console.log(xNodo.dato)
       
       // Despliega lado izquierdo
       this.preOrder(xNodo.hIzq)

       // Despliega lado derecho
       this.preOrder(xNodo.hDer)
    }
    
    // Desplegar en postOrder; Izq, Der y Raiz
    postOrder (xNodo = this.raiz) 
    {
       // Verifica si hay nodo
       if (!xNodo) 
       {
         return
       }
       
       // Despliega el Izq
       this.postOrder(xNodo.hIzq)
       
       // Despliega el Der
       this.postOrder(xNodo.hDer)
       
       // Despliega la Raiz
       console.log(xNodo.dato)
    }
}
  
// Crea un arbol
var arbol = new arbolBinario()

// Inserta elementos al arbol
// 10, 12, 5, -9, 9, 34, 11
arbol.insertar(10)
arbol.insertar(12)
arbol.insertar(5)
arbol.insertar(-9)
arbol.insertar(9)
arbol.insertar(34)
arbol.insertar(11)

// arbol.insertarRecursivamente(10)
// arbol.insertarRecursivamente(12)
// arbol.insertarRecursivamente(5)
// arbol.insertarRecursivamente(-9)
// arbol.insertarRecursivamente(9)
// arbol.insertarRecursivamente(34)
// arbol.insertarRecursivamente(11)

// Despliega in Orden
console.log("Despliegue inOrder ...")
arbol.inOrder()
console.log()

console.log("Despliegue preOrder ...")
arbol.preOrder()
console.log()

console.log("Despliegue postOrder ...")
arbol.postOrder()
console.log()

  













  // find (value) {
    //   if (this.isEmpty()) {
    //     return null
    //   }
  
    //   var aux = this.root
    //   if (aux.value === value) {
    //     return aux
    //   }
  
    //   while(aux) {
    //     // si encontramos el nodo con el valor
    //     // paramos de iterar.
    //     if (aux.value === value) {
    //       break
    //     }
    //     // seguimos buscando a la derecha
    //     if (aux.value < value) {
    //       aux = aux.right
    //     } else if (aux.value > value) {
    //       // seguimos buscando a la izquierda
    //       aux = aux.left
    //     }
    //   }
    //   // retornamos el nodo encontrado.
    //   // si no encontramos el nodo con el valor
    //   // aux, toma el valor null.
    //   return aux
    // }
  
    // findRecursive(value, node = this.root) {
    //   if (node.value === value) {
    //     return node
    //   }
  
    //   if (node.value < value) {
    //     return this.findRecursive(value, node.right)
    //   } else if (node.value > value) {
    //     return this.findRecursive(value, node.left)
    //   }
    // }
  
    // findMin(node = this.root) {
    //   if (!this.isEmpty()) {
    //     /**
    //       * siempre a la izquierda de cualquier nodo
    //       * estará el menor valor.
    //       * iteramos hasta el último menor.
    //       */
    //     while (node.left) {
    //       node = node.left
    //     }
    //     return node
    //   }
    // }
  
    // delete (value, node = this.root) {
    //   if (!node) {
    //     return null
    //   }
    //   if (node.value === value) {
    //     // no tiene hijos
    //     if (!node.left && !node.right) {
    //       return null
    //     }
    //     // no tiene hijo izquierdo
    //     if (!node.left) {
    //       return node.right
    //     }
    //     // no tiene hijo derecho
    //     if (!node.right) {
    //       return node.left
    //     }
  
    //     // tiene dos hijos
    //     // buscamos el menor de los hijos
    //     var temp = this.findMin(node.right)
    //     // con ese valor reemplazamos el valor del nodo que queremos eliminar.
    //     node.value = temp.value;
    //     // seguimos iterando para reemplazar la rama que cambio,
    //     // eliminando el nodo que está repetido
    //     node.right = this.delete(temp.value, node.right)
    //     return node;
    //   }
    //   // buscamos a la derecha
    //   if (node.value < value) {
    //     node.right = this.delete(value, node.right)
    //     return node
    //   }
    //   // buscamos a la izquierda
    //   if (node.value > value) {
    //     node.left = this.delete(value, node.left)
    //     return node
    //   }
    // }
    // print (node = this.root) {
    //   if (!node) {
    //     return
    //   }
    //   this.print(node.left)
    //   console.log(node.value)
    //   this.print(node.right)
    // }
    // /**
    //   * recorre primero toda la rama izquierda
    //   * de izquierda al centro.
    //   * Luego imprime la raíz, y finalmente
    //   * recorre la rama derecha, del centro hacia
    //   * la derecha.
    //   */
