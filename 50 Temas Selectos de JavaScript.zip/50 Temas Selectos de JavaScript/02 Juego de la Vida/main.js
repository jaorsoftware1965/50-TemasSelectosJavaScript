// Juego de la Vida
// Version 1.0
// El programa juega solo, partiendo de un movimiento inicial

// ---------
// Funciones
// ---------

// Para llenar con 0's a la izquierda
function zfill(number, width) 
{
    var numberOutput = Math.abs(number); /* Valor absoluto del número */
    var length = number.toString().length; /* Largo del número */ 
    var zero = "0"; /* String de cero */  
    
    if (width <= length) {
        if (number < 0) {
             return ("-" + numberOutput.toString()); 
        } else {
             return numberOutput.toString(); 
        }
    } else {
        if (number < 0) {
            return ("-" + (zero.repeat(width - length)) + numberOutput.toString()); 
        } else {
            return ((zero.repeat(width - length)) + numberOutput.toString()); 
        }
    }
}
  
// Para obtener un numero aleatorio
function obtenerNumeroAleatorio(min, max) 
{
    return Math.trunc(Math.random() * (max - min) + min);
}


// Clase de Ciudadano
class Ciudadano {

    // Constructor
    constructor (salud, edad, contagio, deterioro, renglon, columna)
    {
        // Valores para todos los ciudadanos
        this.estatus    = "S"        
        this.edad       = edad
        this.salud      = salud
        this.contagio   = contagio
        this.deterioro  = deterioro        
        this.renglon    = renglon
        this.columna    = columna
    }
}

// Clase Ciudad
class Ciudad {

    // Función Constructor
    constructor(filas,    // Numero de Filas de la Ciudad
                columnas) // Numero de Columnas de la Ciudad
    {
        // Propiedades de la Clase
        this.numFilas        = filas     
        this.numColumnas     = columnas  
        this.listaCiudadanos = []        

    }

    // Agregar un Ciudadano
    agregarCiudadano(ciudadano)
    {
        this.listaCiudadanos.push(ciudadano)
    }

    // Función para mostrar la Ciudad
    desplegarCiudad()
    {
        // Define la line vacía
        var linea="";
        
        // Ciclo para desplegar
        this.listaCiudadanos.forEach(element => 
        {
            // Crea la Linea
            linea = linea + "|"+element.estatus+zfill(element.edad,2)+zfill(element.salud,2) + element.contagio + element.deterioro

            // Si es la columna 5 imprime
            if (element.columna==5)
            {
                // le agrega la ultima |
                linea = linea +"|"

                // Imprime la Linea
                console.log(linea)

                // Inicializa la Linea
                linea=""
            }            
            
        });
    }

    // Contagiar
    contagiar(renglon,columna)
    {
        // Variable indice
        var index=0;

        // Ciclo para buscar el elemento
        for (index=0; index<25; index++)
        {
            // Verifica si coincide
            if (this.listaCiudadanos[index].columna == columna && 
                this.listaCiudadanos[index].renglon == renglon)
            {
                // Modifica el Estado
                this.listaCiudadanos[index].estatus ="C"
                
                // Despliega el Elemento
                console.log(this.listaCiudadanos[index])
            }
            
        };
    }
}

 

// ------------------
// Programa Principal
// ------------------

// Crea una ciudad
ciudadMexico = new Ciudad(5,5)

// Variable de indice
var index;
var renglon = 1;
var columna = 1;

// Ciclo para generar aleatoriamente 25 ciudadanos
for (index=0; index<25;index++)
{
    // Genera un numero aleatorio para la salud
    let salud = obtenerNumeroAleatorio(50,99)

    // Genera un numero aleatorio para la edad
    let edad = obtenerNumeroAleatorio(1,100)

    // Genera un numero aleatorio para el contagio
    let contagio = obtenerNumeroAleatorio(1,3)

    // Genera un numero aleatorio para el deterioro
    let deterioro = obtenerNumeroAleatorio(1,3)

    // Crea un nuevo ciudadano
    ciudadano = new Ciudadano(salud,edad,contagio,deterioro, renglon, columna) 

    // Agregar el Ciudadano a la Ciudad
    ciudadMexico.agregarCiudadano(ciudadano)

    // Incremento la columna
    columna++

    //  Verifico si ya rebaso el 5
    if (columna >5)
    {
        // Coloco 1 en columna
        columna=1;
        
        // Incremento el renglón
        renglon++;
    }
}

// Despliega el Tablero
ciudadMexico.desplegarCiudad()

// Crea el renglon aleatorio para la infeccion inicial
let ren = obtenerNumeroAleatorio(1,5)
let col = obtenerNumeroAleatorio(1,5)

// Contagio Inicial
console.log("Contagio inicial: ren:",ren,"col:",col)

// Contagiando al primer ciudadano
ciudadMexico.contagiar(ren,col)

// Ciclo para contagiar e inmunizar
while(true)
{
    
    setTimeout(function() {
        return console.log("cue");
    }, 100);
    
}

// Programa terminado
console.log("Programa terminado ...")
