// ---------------------------------------------------------------------
// Programa para generar Clientes Aleatorios con Provincia y Población
// Utilizando el archivo de Codigos Postales de España
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// Se incluyen las librerías
const csv = require('csv-parser')
const fs = require('fs')
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// Variables globales

// Para los registros
const registros = [];

// Para contar los clientes
var cuentaClientes=0;

// Los arreglos para el Cliente, ciudad y Provincia
var listaClientes    = [];
var listaProvincias  = [];
var listaPoblaciones = [];

// --------------------------------------------------------------------

// --------------------------------------------------------------------
// Funciones 
// Para llenar con 0's a la izquierda
function zfill(number, width) {
  var numberOutput = Math.abs(number); /* Valor absoluto del número */
  var length = number.toString().length; /* Largo del número */ 
  var zero = "0"; /* String de cero */  
  
  if (width <= length) {
      if (number < 0) {
           return ("-" + numberOutput.toString()); 
      } else {
           return numberOutput.toString(); 
      }
  } else {
      if (number < 0) {
          return ("-" + (zero.repeat(width - length)) + numberOutput.toString()); 
      } else {
          return ((zero.repeat(width - length)) + numberOutput.toString()); 
      }
  }
}

// Para obtener un numero aleatorio
function obtenerNumeroAleatorio(min, max) {
  return Math.trunc(Math.random() * (max - min) + min);
}
// ------------------------------------------------------------------


// ------------------------------------------------------------------
// Código Principal
// ------------------------------------------------------------------


// Abre el Archivo (cambiara data por el nombre de tu archivo de codigos)
fs.createReadStream('data.csv')
  .pipe(csv())
  .on('data', (data) => registros.push(data))
  .on('end', () => 
  {    

    // Ciclo para generar los 5 registros de Clientes, Provincias y Poblaciones
    // Ciclo for
    for (cuentaClientes = 0; cuentaClientes < 5; cuentaClientes++) 
    {

      // Obtengo el numero aleatorio
      var indice = obtenerNumeroAleatorio(0,14664)
    
      // Otengo un renglon
      var renglon = registros[indice];
      console.log("renglon:",renglon)
    
      // Obtenemos los datos del Renglón en cadena
      var datoCadena =  renglon['provincia";"poblacion";"codigopostalid']
      
      
      // Separamos los datos
      datoCadena = datoCadena.split(";")

      // Eliminamos las comillas excendentes
      datoCadena[0]=datoCadena[0].replace('"','')
      datoCadena[1]=datoCadena[1].replace('"','')
      datoCadena[1]=datoCadena[1].replace('"','')
      datoCadena[2]=datoCadena[2].replace('"','')

      // Variable para el CP
      var prefijoCodigoPostal = datoCadena[2].substring(0,2)
      var cliente = prefijoCodigoPostal + zfill(cuentaClientes,4);

      // Agregamos el Cliente a la lista
      listaClientes.push(cliente)

      // Agregamos las provincias y poblaciones
      listaProvincias.push(datoCadena[0])
      listaPoblaciones.push(datoCadena[1])

    }  
    console.log("Lista de Clientes")
    console.log(listaClientes)
    console.log("Lista de Provincias")
    console.log(listaProvincias)
    console.log("Lista de Poblaciones")
    console.log(listaPoblaciones)
    
  });
  
  
  