// ---------------------------------------------------------------------
// Objetivo:
// Leer una archivo de Clientes CSV
// Filtrar únicamente los de la provincia Pontevedra y que tengan correo
// Ordenar por fecha de ultima venta
// ---------------------------------------------------------------------

// Se incluyen las librerías
const csv = require("csv-parser");
const fs = require("fs");
//const createCsvWriter = require("csv-writer").createObjectCsvWriter;

// Definición de variables
const registros = [];
let   data = [];
let   registrosFiltrados = []

// Funciones
function fechaesMenor(fecha1, fecha2) 
{
    let fechaf = fecha1.split("/");
    let day = fechaf[0];
    let month = fechaf[1];
    let year = fechaf[2];
    let fechaf2 = fecha2.split("/");
    let day2 = fechaf2[0];
    let month2 = fechaf2[1];
    let year2 = fechaf2[2];
    if (
        new Date(year + "/" + month + "/" + day) <
        new Date(year2 + "/" + month2 + "/" + day2)
    ) {
        return true;
    } else {
        return false;
    }
}

// Código principal
fs.createReadStream("clientes.csv")
    .pipe(csv())
    .on("data", (data) => registros.push(data))
    .on("end", () => {
        registros.forEach(element => {
            if (element.Provincia == 'Pontevedra' && element.Email != '') {
                registrosFiltrados.push(element)
            }
        });
        
        //console.log(registrosFiltrados)
        registrosFiltrados.sort(function (a, b) {
            if (fechaesMenor(a['Ultima-venta'] , b['Ultima-venta'])) {
              return -1;
            }
            if (!fechaesMenor(a['Ultima-venta'],b['Ultima-venta'])) {
              return 1;
            }
            // a must be equal to b
            //return 0;
          });          
          console.log(registrosFiltrados)
          registrosFiltrados.forEach(element => {
          console.log(element.Cliente,element['Ultima-venta'])
        });
    });